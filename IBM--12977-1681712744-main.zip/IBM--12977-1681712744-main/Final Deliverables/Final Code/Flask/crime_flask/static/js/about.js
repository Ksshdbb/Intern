// about.js

// You can include any JavaScript code here as needed for animations or interactivity
// For example, if you want to add a click event listener to the member cards:

const memberCards = document.querySelectorAll('.member-card');

memberCards.forEach((card) => {
  card.addEventListener('click', () => {
    // Handle the click event here
    // You can perform actions like showing more information, opening a modal, etc.
  });
});
